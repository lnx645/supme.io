---
name: Trakteer Design System
colors:
  surface: '#fbf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#3f4a36'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#6f7b64'
  outline-variant: '#becbb1'
  surface-tint: '#2b6c00'
  primary: '#2b6c00'
  on-primary: '#ffffff'
  primary-container: '#58cc02'
  on-primary-container: '#1e5000'
  inverse-primary: '#6be026'
  secondary: '#006590'
  on-secondary: '#ffffff'
  secondary-container: '#2fb8ff'
  on-secondary-container: '#004666'
  tertiary: '#6f5d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#d1b200'
  on-tertiary-container: '#524500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#87fe45'
  primary-fixed-dim: '#6be026'
  on-primary-fixed: '#082100'
  on-primary-fixed-variant: '#1f5100'
  secondary-fixed: '#c8e6ff'
  secondary-fixed-dim: '#88ceff'
  on-secondary-fixed: '#001e2e'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffe165'
  tertiary-fixed-dim: '#e7c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  display-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.5'
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.5'
  label-bold:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system is built on the philosophy of **Gamified Support**. It transforms the act of creator patronage into an engaging, rewarding, and joyful experience. The personality is relentlessly optimistic, approachable, and high-energy, aimed at Gen Z and Millennial users who value community and play.

The visual style is **Tactile Playfulness**. It utilizes heavy "chunky" elements, bright saturated colors, and a 3D-pressable aesthetic that mimics physical arcade buttons. Every interaction should feel satisfying and "crunchy," providing immediate visual feedback that reinforces the user's positive action of supporting a creator.

Key tenets:
- **Exuberance:** Use vibrant colors and bold weights to celebrate small wins.
- **Simplicity:** Minimize cognitive load through clear visual hierarchies and large touch targets.
- **Character:** Infuse the UI with personality using expressive iconography and friendly, rounded geometry.

## Colors

The palette is centered around "Action Green" and "Inspiration Blue." 

- **Primary Green:** Reserved for success states, primary calls to action, and positive progression.
- **Secondary Blue:** Used for discovery, navigation, and informational highlights.
- **3D Shading:** Every interactive color has a corresponding "Shade" (a darker version). This is used for the bottom border of buttons to create a physical depth effect.
- **High Contrast:** Text and borders use a dark charcoal rather than pure black to maintain friendliness while ensuring WCAG AAA accessibility for core text.

## Typography

This design system uses a dual-font approach to balance personality with readability.

- **Headlines (Plus Jakarta Sans):** Set in Extra Bold weights. Use these for titles, "celebration" messages, and large numbers (like donation amounts).
- **Body (Be Vietnam Pro):** A slightly more legible and contemporary sans-serif for descriptions, labels, and long-form content. 
- **Scale:** Maintain large minimum sizes (16px) to ensure the UI feels "chunky" and accessible. All headings should feel weighty and authoritative.

## Layout & Spacing

The layout follows a **soft-grid system** based on 4px increments.

- **Grid:** On desktop, use a 12-column centered layout with a maximum container width of 1040px to maintain focus. On mobile, use a single column with 16px side margins.
- **Visual Breathing Room:** Content is heavily padded within cards (typically 24px) to ensure a clean, uncluttered look.
- **Rhythm:** Use `lg` (24px) or `xl` (32px) for vertical rhythm between major sections. Smaller units like `sm` (8px) are reserved for internal component spacing (e.g., icon to text).

## Elevation & Depth

This design system rejects traditional soft shadows in favor of **Structural Depth**.

- **The 3D Effect:** Buttons and active cards use a 2px to 4px solid bottom border (the "Shade" color). When "pressed," the element should translate Y-down by the same amount, making the bottom border disappear and simulating a physical click.
- **Cards:** Use a 2px solid border in the `#E5E5E5` color. A very soft, large-radius shadow (`0px 4px 0px 0px rgba(0,0,0,0.05)`) can be used to distinguish floating elements, but the solid border is the primary means of separation.
- **Layers:** Backgrounds should remain white or extremely light gray (`#F7F7F7`) to let the colorful 3D components pop.

## Shapes

The shape language is defined by **Extreme Roundness**. 

- **Standard Elements:** Buttons, cards, and input fields use a minimum radius of 16px, scaling up to 24px or 32px for larger containers.
- **Pill Shapes:** Small tags, badges, and progress bar containers should always be fully rounded (pill-shaped).
- **Consistency:** Avoid sharp corners entirely. Even "inner" corners of nested elements should be rounded to maintain the friendly, approachable aesthetic.

## Components

### Buttons
Buttons are the core of this design system. They must have a "chunky" 3D look:
- **Base:** Solid background color with white text.
- **Depth:** A 4px solid bottom border in the "Shade" color.
- **Active State:** On click/tap, the button moves down 4px, and the shadow disappears.

### Cards
- **Support Cards:** 2px solid border, 24px border radius. Padding should be generous (`24px`).
- **Interactive Cards:** Same as support cards but can include a 2px "lift" shadow that increases on hover.

### Progress Bars
- **Container:** Thick, pill-shaped, with a light gray background (`#E5E5E5`).
- **Fill:** Bright Primary Green or Secondary Blue. 
- **Effect:** Include a "glossy" highlight or a subtle striped pattern to the fill to make it feel dynamic.

### Badges & Streaks
- **Streak Icon:** Use an orange flame icon with a bold number in Plus Jakarta Sans.
- **Badges:** Circular or hex-shaped with thick 2px borders and a high-contrast icon in the center.

### Inputs
- **Chunky Fields:** 2px border width, 16px padding. 
- **Focus State:** Border color changes to Secondary Blue with a 4px bottom "depth" border added to the field itself to make it feel "inserted" into the page.

### Mascots
- **Placement:** Use friendly, illustrated characters to provide feedback (e.g., a "Celebration" mascot on a successful donation page or a "Encouragement" mascot on an empty state).